/* eslint-disable prettier/prettier */
export interface JwtPayload {
  id: number;
  mail: string;
  name_user:string;
}
